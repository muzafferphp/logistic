<?php $__env->startSection('content'); ?>  
	<!-- partial -->
        <div class="content-wrapper">
          <div class="row">
			
			<div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Add truck</h4>
                  <form class="form-sample" method="post" action="<?php echo e(route('add.tuck')); ?>">
				  <?php echo csrf_field(); ?>
				  
				<?php if(session('success')): ?>
					<div class="alert alert-info"><?php echo e(session('success')); ?></div>
				<?php endif; ?>
                    <p class="card-description">
                      Details info
                    </p>
                    <div class="row">
                      <div class="col-md-6">
                        
						<?php if($errors->has('company_name')): ?>
						<div class="error text-danger"><?php echo e($errors->first('company_name')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Company name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="company_name" name="company_name" placeholder="Company name">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        
						<?php if($errors->has('postal_address')): ?>
						<div class="text-danger"><?php echo e($errors->first('postal_address')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Postal Address</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="postal_address" name="postal_address" placeholder="Postal Address">
                          </div>
                        </div>
                      </div>
                    </div>
					
                    <div class="row">
                      <div class="col-md-6">
                       
						<?php if($errors->has('abn')): ?>
						<div class="text-danger"><?php echo e($errors->first('abn')); ?></div>
						<?php endif; ?>
						 <div class="form-group row">
                          <label class="col-sm-3 col-form-label">ABN </label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="abn" name="abn" placeholder="ABN">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                       
						<?php if($errors->has('contact_number')): ?>
						<div class="text-danger"><?php echo e($errors->first('contact_number')); ?></div>
					    <?php endif; ?>
						 <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Contact number</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="contact_number" name="contact_number" placeholder="Company name">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        
						<?php if($errors->has('phone_number')): ?>
						<div class="text-danger"><?php echo e($errors->first('phone_number')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Phone number</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="phone_number" name="phone_number" placeholder="Company name">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        
						<?php if($errors->has('email')): ?>
						<div class="text-danger"><?php echo e($errors->first('email')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                          </div>
                        </div>
                      </div>
                    </div>
					
					<div class="row">
                      <div class="col-md-6">
                       
						<?php if($errors->has('key_contact')): ?>
						<div class="text-danger"><?php echo e($errors->first('key_contact')); ?></div>
						<?php endif; ?>
						 <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Key contact</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="key_contact" name="key_contact" placeholder="Key contact">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        
						<?php if($errors->has('truck_type')): ?>
						<div class="text-danger"><?php echo e($errors->first('truck_type')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Type of Truck</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="truck_type" name="truck_type" placeholder="Type of Truck">
                          </div>
                        </div>
                      </div>
                    </div>
					
					
                    <div class="row">
                      <div class="col-md-6">
                      
						<?php if($errors->has('dry_reefer')): ?>
						<div class="text-danger"><?php echo e($errors->first('dry_reefer')); ?></div>
						<?php endif; ?>
						  <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Dry or reefer</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" id="dry_reefer" name="dry_reefer" placeholder="Dry or reefer">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        
						<?php if($errors->has('insurance_number')): ?>
						<div class="error text-danger"><?php echo e($errors->first('insurance_number')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Insurance number</label>
                          <div class="col-sm-9">
						   <input type="text" class="form-control" id="insurance_number" name="insurance_number" placeholder="Insurance number">
                          </div>
                        </div>
                      </div>
                    </div>
					
					 <div class="row">
                     
                      <div class="col-md-6">
                        
						<?php if($errors->has('permit_type')): ?>
						<div class="error text-danger"><?php echo e($errors->first('permit_type')); ?></div>
						<?php endif; ?>
						<div class="form-group row">
                          <label class="col-sm-3 col-form-label">Type of permit</label>
                          <div class="col-sm-9">
						   <input type="text" class="form-control" id="permit_type" name="permit_type" placeholder="Type of permit">
                          </div>
                        </div>
                      </div>
					  
					   <div class="col-md-6">
                        <div class="form-group row">
                          
                          <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                          </div>
                        </div>
                      </div>
                    </div>
					
					
                  </form>
                </div>
              </div>
            </div>
			
			
			
		</div>
	
	<!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u226382986/domains/himtreasure.com/public_html/logistics/resources/views/carrier/truck.blade.php ENDPATH**/ ?>