<?php $__env->startSection('content'); ?> 

<!-- login section start here -->
<div class="page-title-area bg-8">
   <div class="container">
      <div class="page-title-content">
         <h2>Log In</h2>
         <ul>
            <li>
               <a href="index.html">
               Home
               </a>
            </li>
            
               <i class='bx bx-chevrons-right'></i>
            
            <li class="active">Log In</li>
         </ul>
      </div>
   </div>
</div>
<section class="user-area-style ptb-100">
	<div class="container">
		<div class="contact-form-action">
			<div class="account-title">
				<h2>Log in</h2>
			</div>
				<?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				<?php endif; ?>
				 

				 <?php if(Session::has('message')): ?>
					<p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
				<?php endif; ?>
		
			<form method="post" action="<?php echo e(route('login')); ?>" >
			  <?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-12">
						<div class="form-group">
							<label>Email or Phone</label>
							<input class="form-control" type="email" name="email" required> 
						</div>
					</div>
					<div class="col-12">
						<div class="form-group">
							<label>Password</label>
							<input class="form-control" type="password" name="password">
						</div>
					</div>
					<div class="col-12">
						<div class="login-action">
							<span class="log-rem">
								<input id="remember" type="checkbox">
								<label for="remember">Remember me!</label>
							</span>
							<span class="forgot-login">
								<a href="<?php echo e(route('user.password')); ?>">Forgot your password?</a>
							</span>
						</div>
					</div>
					<div class="col-12">
						<button type="submit" class="default-btn" >
							<span>Log in now</span>
						</button>
					</div>
					<div class="col-12">
						<p>Have an account? <a href="<?php echo e(route('user.register')); ?>">Registration Now!</a></p>
					</div>
				</div>
			</form>
		</div>
	</div>
</section>
      <!-- login section end here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u226382986/domains/himtreasure.com/public_html/logistics/resources/views/user/login.blade.php ENDPATH**/ ?>