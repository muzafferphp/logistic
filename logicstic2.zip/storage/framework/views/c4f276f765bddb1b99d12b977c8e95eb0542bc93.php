<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link href="<?php echo e(asset('front/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
      <link href="<?php echo e(asset('front/assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/flaticon.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/boxicons.min.css')); ?>" />
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/owl.theme.default.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('front/assets/css/owl.carousel.min.css')); ?>">
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
      <title>Logistics</title>
   </head>
   <body>


<?php echo $__env->make('Front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('Front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	  
      <!-- footer section start here -->
      <script src="<?php echo e(asset('front/assets/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('front/assets/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('front/assets/js/owl.carousel.min.js')); ?>"></script>
      <script src="<?php echo e(asset('front/assets/js/custom.js')); ?>"></script>
      <script src="<?php echo e(asset('front/assets/js/bootstrap.min.js')); ?>"></script>
	  
	  	  
	  <script>
		
		$('#remember-1').change(function() {
			$(this).is(':checked') ? $('#test-input').attr('type', 'text') : $('#test-input').attr('type', 'password');
		});
	  </script>
   </body>
</html>
</html><?php /**PATH C:\xampp\htdocs\logicstic\resources\views/Front/layouts/layout.blade.php ENDPATH**/ ?>