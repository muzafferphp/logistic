<?php $__env->startSection('content'); ?> 

      <!-- blog section start here -->
      <section class="blog-area">
         <div class="container">
            <div class="section-title">
               <span>Truck list</span>
			</div>
            <div class="row">
			
			
				
			<div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Truck Table</h4>
				  
				<?php if(session('success')): ?>
					<div class="alert alert-info w-50"><?php echo e(session('success')); ?></div>
				<?php endif; ?>
                  
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Company</th>
                          <th>Address</th>
                          <th>Contact</th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Truck type</th>
                          <th>Insurance</th>
                          <th>Permit type</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
					  
						<?php $__currentLoopData = $truecklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  
                        <tr>
                          <td><?php echo e($truck->company_name); ?></td>
                          <td><?php echo e($truck->postal_address); ?></td>
                          <td><?php echo e($truck->contact_number); ?></td>
                          <td><?php echo e($truck->phone_number); ?></td>
                          <td><?php echo e($truck->email); ?></td>
                          <td><?php echo e($truck->truck_type); ?></td>
                          <td><?php echo e($truck->insurance_number); ?></td>
						  <td><?php echo e($truck->permit_type); ?></td>
                          <td>
							<label class="badge badge-info"><a href="<?php echo e(route('tuck.view',$truck->id)); ?>">Truck view</a></label>
						  </td>
                        </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
			
			
            </div>
         </div>
      </section>
      <!-- blog section end here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logicstic\resources\views/Front/truck_list.blade.php ENDPATH**/ ?>