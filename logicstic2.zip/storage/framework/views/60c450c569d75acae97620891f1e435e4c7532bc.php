      <!-- header section start here -->
      <header class="header-area">
         <div class="top-header">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-lg-8 col-md-7">
                     <ul class="header-left-content">
                        <li>
                           <i class="bx bx-home"></i>
                           9170 Millbrook Rd, Newark, IL 60541
                        </li>
                        <li>
                           <i class="bx bx-phone-call"></i>
                           <a href="tel:+1-(123)-456-7890">+1 (123) 456 7890</a>
                        </li>
                        <li>
                           <i class="bx bx-envelope"></i>
                           <a href="mailto:hello@ezio.com">hello@ezio.com</a>
                        </li>
                     </ul>
                  </div>
                  <div class="col-lg-4 col-md-5">
                     <div class="header-right-content">
                        <ul class="button_sections">
                           <li>
                              <a href="<?php echo e(route('login')); ?>"><span>Login</span></a>
                           </li>
                           <li>
                              <a href="#" class="start_shipping"><span>Start Shipping</span></a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="navbar-section">
            <div class="container">
               <nav class="navbar navbar-expand-lg">
                  <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('front/assets/images/logo.png')); ?>" title="logo" alt="logo" /></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"><i class='bx bx-menu'></i></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarText">
                     <ul class="navbar-nav m-auto">
                        <li class="nav-item">
                           <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">About</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Blogs</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Contact Us</a>
                        </li>
                     </ul>
                     <span class="navbar-text">
                     <a href=""> Get A Quote</a>
                     </span>
                  </div>
               </nav>
            </div>
         </div>
      </header>
      <!-- header section end here --><?php /**PATH /home/u226382986/domains/himtreasure.com/public_html/logistics/resources/views/Front/layouts/header.blade.php ENDPATH**/ ?>