<?php $__env->startSection('content'); ?> 

<section class="user-area-style ptb-100">
  <div class="container">
    <div class="contact-form-action">
      <div class="account-title">
        <h2>Registration</h2>
		
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		 

		 <?php if(Session::has('message')): ?>
		<p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
		<?php endif; ?>

      </div>
      <form action="<?php echo e(route('carrier.register')); ?>" method="post">
	  <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-12">
            <div class="form-group">
              <label>Full name</label>
              <input class="form-control" type="text" name="name" required>
            </div>
          </div>
          <div class="col-12">
            <div class="form-group">
              <label>Email address</label>
              <input class="form-control" type="email" name="email" required>
            </div>
          </div>
          <div class="col-12">
            <div class="form-group">
              <label>Mobile no.</label>
              <input class="form-control" type="tel" name="mobile" required>
            </div>
          </div>
          <div class="col-12">
            <div class="form-group">
              <label>Password</label>
              <input class="form-control" type="password" name="password" id="test-input" required>
            </div>
          </div>
          <div class="col-12">
            <div class="row align-items-center">
              <div class="col-lg-6 col-sm-6">
                <button class="default-btn register" type="submit">
                  <span>Register now</span>
                </button>
              </div>
              <div class="col-lg-6 col-sm-6 text-right">
                <input id="remember-1" type="checkbox">
                <label>Show password ?</label>
              </div>
            </div>
          </div>
          <div class="col-12">
            <p>Have an account? <a href="<?php echo e(route('carrier.login')); ?>">Login now!</a>
            </p>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>
      <!-- Register section end here -->
	  
	  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logicstic\resources\views/carrier/register.blade.php ENDPATH**/ ?>