<?php $__env->startSection('content'); ?> 

<div class="jumbotron text-center">
  <h1>Truck info details</h1>
  <p>Company : <?php echo e($truck->company_name); ?></p> 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <p>Address : <?php echo e($truck->postal_address); ?></p>
      <p>ABN : <?php echo e($truck->abn); ?></p>
      <p>Contact : <?php echo e($truck->contact_number); ?></p>
      <p>Date : <?php echo e($truck->created_at); ?></p>
    </div>
    <div class="col-sm-4">
		<p>Phone : <?php echo e($truck->phone_number); ?></p>
		<p>Email : <?php echo e($truck->email); ?></p>
		<p>Key Contact : <?php echo e($truck->key_contact); ?></p>
    </div>
    <div class="col-sm-4">
		<p>Truck type : <?php echo e($truck->truck_type); ?></p>
        <p>Dry reefer : <?php echo e($truck->dry_reefer); ?></p>
        <p>Insurance : <?php echo e($truck->insurance_number); ?></p>
        <p>Permit type : <?php echo e($truck->permit_type); ?></p>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\logicstic\resources\views/Front/truck.blade.php ENDPATH**/ ?>