<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 
 <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>Truck info details</h1>
  <p>Company : <?php echo e($truck->company_name); ?></p> 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <p>Address : <?php echo e($truck->postal_address); ?></p>
      <p>ABN : <?php echo e($truck->abn); ?></p>
      <p>Contact : <?php echo e($truck->contact_number); ?></p>
      <p>Date : <?php echo e($truck->created_at); ?></p>
    </div>
    <div class="col-sm-4">
		<p>Phone : <?php echo e($truck->phone_number); ?></p>
		<p>Email : <?php echo e($truck->email); ?></p>
		<p>Key Contact : <?php echo e($truck->key_contact); ?></p>
    </div>
    <div class="col-sm-4">
		<p>Truck type : <?php echo e($truck->truck_type); ?></p>
        <p>Dry reefer : <?php echo e($truck->dry_reefer); ?></p>
        <p>Insurance : <?php echo e($truck->insurance_number); ?></p>
        <p>Permit type : <?php echo e($truck->permit_type); ?></p>
    </div>
  </div>
</div>

</body>
</html>
<?php /**PATH /home/u226382986/domains/himtreasure.com/public_html/logistics/resources/views/Front/truck.blade.php ENDPATH**/ ?>